import os
import time
import pickle

class Usuario:
    def __init__(self, id, nome, email, telefone, login, senha):
        self.id = id
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.login = login
        self.senha = senha
        self.bloqueado = False
        self.livros_emprestados = []
    
    def __str__(self):
        status = "BLOQUEADO" if self.bloqueado else "ATIVO"
        return f"ID: {self.id} | Nome: {self.nome} | Email: {self.email} | Telefone: {self.telefone} | Login: {self.login} | Status: {status} | Livros emprestados: {len(self.livros_emprestados)}"

class SistemaBiblioteca:
    def __init__(self, admin_username, admin_senha, arquivo_dados="biblioteca_dados.bin"):
        self.arquivo_dados = arquivo_dados
        
        dados_carregados = self.carregar_dados()
        
        if dados_carregados:
            self.usuarios = dados_carregados['usuarios']
            self.proximo_id = dados_carregados['proximo_id']
        else:
            self.usuarios = {}
            self.proximo_id = 1
        
        self.admin_username = admin_username
        self.admin_senha = admin_senha
        self.admin_logado = False
        self.usuario_logado = None
    
    def salvar_dados(self):
        """Salva os dados em arquivo binário usando pickle"""
        dados = {
            'usuarios': self.usuarios,
            'proximo_id': self.proximo_id
        }
        
        try:
            with open(self.arquivo_dados, 'wb') as arquivo:
                pickle.dump(dados, arquivo)
            return True
        except Exception as e:
            print(f"Erro ao salvar dados: {e}")
            return False
    
    def carregar_dados(self):
        """Carrega os dados do arquivo binário"""
        try:
            if os.path.exists(self.arquivo_dados):
                with open(self.arquivo_dados, 'rb') as arquivo:
                    return pickle.load(arquivo)
            return None
        except Exception as e:
            print(f"Erro ao carregar dados: {e}")
            return None
    
    def login_admin(self, username, senha):
        """Realiza login do administrador"""
        if username == self.admin_username and senha == self.admin_senha:
            self.admin_logado = True
            return True
        else:
            return False
    
    def logout_admin(self):
        """Realiza logout do administrador"""
        self.admin_logado = False
    
    def login_usuario(self, login, senha):
        """Realiza login de usuário comum"""
        for usuario in self.usuarios.values():
            if usuario.login == login and usuario.senha == senha and not usuario.bloqueado:
                self.usuario_logado = usuario
                return True, f"Bem-vindo, {usuario.nome}!"
        
        for usuario in self.usuarios.values():
            if usuario.login == login and usuario.senha == senha and usuario.bloqueado:
                return False, "Seu acesso está bloqueado. Entre em contato com o administrador."
        
        return False, "Login ou senha incorretos."
    
    def logout_usuario(self):
        """Realiza logout de usuário comum"""
        self.usuario_logado = None
    
    def adicionar_usuario(self, nome, email, telefone, login, senha):
        """Adiciona um novo usuário ao sistema"""
        for usuario in self.usuarios.values():
            if usuario.email == email:
                return None, "Email já cadastrado"
        
        for usuario in self.usuarios.values():
            if usuario.login == login:
                return None, "Login já cadastrado"
        
        novo_usuario = Usuario(self.proximo_id, nome, email, telefone, login, senha)
        self.usuarios[self.proximo_id] = novo_usuario
        self.proximo_id += 1
        
        self.salvar_dados()
        
        return novo_usuario, f"Usuário adicionado com sucesso. ID: {novo_usuario.id}"
    
    def bloquear_usuario(self, id_usuario):
        """Bloqueia um usuário pelo ID"""
        if id_usuario in self.usuarios:
            usuario = self.usuarios[id_usuario]
            usuario.bloqueado = True
            
            self.salvar_dados()
            
            return True, f"Usuário {usuario.nome} (ID: {usuario.id}) foi bloqueado."
        else:
            return False, f"Usuário com ID {id_usuario} não encontrado."
    
    def desbloquear_usuario(self, id_usuario):
        """Desbloqueia um usuário pelo ID"""
        if id_usuario in self.usuarios:
            usuario = self.usuarios[id_usuario]
            usuario.bloqueado = False
            
            self.salvar_dados()
            
            return True, f"Usuário {usuario.nome} (ID: {usuario.id}) foi desbloqueado."
        else:
            return False, f"Usuário com ID {id_usuario} não encontrado."
    
    def listar_usuarios(self):
        """Lista todos os usuários cadastrados"""
        return list(self.usuarios.values())
    
    def buscar_usuario(self, id_usuario):
        """Busca um usuário pelo ID"""
        if id_usuario in self.usuarios:
            return self.usuarios[id_usuario], "Usuário encontrado"
        return None, "Usuário não encontrado"


def limpar_tela():
    """Limpa a tela do terminal"""
    os.system('cls' if os.name == 'nt' else 'clear')


def exibir_menu_principal():
    """Exibe o menu principal do sistema"""
    limpar_tela()
    print("\n===== SISTEMA DE BIBLIOTECA =====")
    print("1. Login como Administrador")
    print("2. Login como Usuário")
    print("0. Sair")
    return input("\nEscolha uma opção: ")


def exibir_menu_admin():
    """Exibe o menu do administrador"""
    limpar_tela()
    print("\n===== MENU DO ADMINISTRADOR =====")
    print("1. Adicionar Usuário")
    print("2. Bloquear Usuário")
    print("3. Desbloquear Usuário")
    print("4. Listar Todos os Usuários")
    print("5. Buscar Usuário por ID")
    print("0. Logout")
    return input("\nEscolha uma opção: ")


def exibir_menu_usuario():
    """Exibe o menu do usuário comum"""
    limpar_tela()
    print("\n===== MENU DO USUÁRIO =====")
    print("1. Ver Meus Dados")
    print("2. Ver Livros Emprestados")
    print("0. Logout")
    return input("\nEscolha uma opção: ")


def executar_sistema():
    """Função principal para executar o sistema"""
    sistema = SistemaBiblioteca("admin", "admin123")
    
    while True:
        opcao = exibir_menu_principal()
        
        if opcao == "1":
            limpar_tela()
            print("\n===== LOGIN DE ADMINISTRADOR =====")
            username = input("Username: ")
            senha = input("Senha: ")
            
            if sistema.login_admin(username, senha):
                print("\nLogin realizado com sucesso!")
                time.sleep(1)
                
                while sistema.admin_logado:
                    opcao_admin = exibir_menu_admin()
                    
                    if opcao_admin == "1":
                        limpar_tela()
                        print("\n===== ADICIONAR NOVO USUÁRIO =====")
                        nome = input("Nome completo: ")
                        email = input("Email: ")
                        telefone = input("Telefone: ")
                        login = input("Login para o usuário: ")
                        senha = input("Senha para o usuário: ")
                        
                        usuario, mensagem = sistema.adicionar_usuario(nome, email, telefone, login, senha)
                        if usuario:
                            print(f"\n {mensagem}")
                        else:
                            print(f"\n Erro: {mensagem}")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_admin == "2":
                        limpar_tela()
                        print("\n===== BLOQUEAR USUÁRIO =====")
                        try:
                            id_usuario = int(input("ID do usuário: "))
                            sucesso, mensagem = sistema.bloquear_usuario(id_usuario)
                            if sucesso:
                                print(f"\n {mensagem}")
                            else:
                                print(f"\n Erro: {mensagem}")
                        except ValueError:
                            print("\n Erro: ID inválido.")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_admin == "3":
                        limpar_tela()
                        print("\n===== DESBLOQUEAR USUÁRIO =====")
                        try:
                            id_usuario = int(input("ID do usuário: "))
                            sucesso, mensagem = sistema.desbloquear_usuario(id_usuario)
                            if sucesso:
                                print(f"\n {mensagem}")
                            else:
                                print(f"\n Erro: {mensagem}")
                        except ValueError:
                            print("\n Erro: ID inválido.")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_admin == "4":
                        limpar_tela()
                        print("\n===== LISTA DE USUÁRIOS =====")
                        usuarios = sistema.listar_usuarios()
                        
                        if not usuarios:
                            print("Nenhum usuário cadastrado.")
                        else:
                            for usuario in usuarios:
                                print(usuario)
                            print(f"\nTotal: {len(usuarios)} usuários cadastrados.")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_admin == "5":
                        limpar_tela()
                        print("\n===== BUSCAR USUÁRIO =====")
                        try:
                            id_usuario = int(input("ID do usuário: "))
                            usuario, mensagem = sistema.buscar_usuario(id_usuario)
                            if usuario:
                                print(f"\nUsuário encontrado:")
                                print(usuario)
                            else:
                                print(f"\n {mensagem}")
                        except ValueError:
                            print("\n Erro: ID inválido.")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_admin == "0":
                        sistema.logout_admin()
                        print("\nLogout realizado com sucesso!")
                        time.sleep(1)
            else:
                print("\n Erro: Credenciais inválidas.")
                input("\nPressione ENTER para continuar...")
                
        elif opcao == "2":
            limpar_tela()
            print("\n===== LOGIN DE USUÁRIO =====")
            login = input("Login: ")
            senha = input("Senha: ")
            
            sucesso, mensagem = sistema.login_usuario(login, senha)
            
            if sucesso:
                print(f"\n {mensagem}")
                time.sleep(1)
                while sistema.usuario_logado:
                    opcao_usuario = exibir_menu_usuario()
                    
                    if opcao_usuario == "1":
                        limpar_tela()
                        print("\n===== MEUS DADOS =====")
                        print(f"Nome: {sistema.usuario_logado.nome}")
                        print(f"Email: {sistema.usuario_logado.email}")
                        print(f"Telefone: {sistema.usuario_logado.telefone}")
                        print(f"Login: {sistema.usuario_logado.login}")
                        print(f"Status: {'BLOQUEADO' if sistema.usuario_logado.bloqueado else 'ATIVO'}")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_usuario == "2":
                        limpar_tela()
                        print("\n===== LIVROS EMPRESTADOS =====")
                        if not sistema.usuario_logado.livros_emprestados:
                            print("Você não possui livros emprestados no momento.")
                        else:
                            for i, livro in enumerate(sistema.usuario_logado.livros_emprestados, 1):
                                print(f"{i}. {livro}")
                        
                        input("\nPressione ENTER para continuar...")
                        
                    elif opcao_usuario == "0":
                        sistema.logout_usuario()
                        print("\nLogout realizado com sucesso!")
                        time.sleep(1)
            else:
                print(f"\n {mensagem}")
                input("\nPressione ENTER para continuar...")
                
        elif opcao == "0":
            print("\nEncerrando o sistema. Até logo!")
            break
        
        else:
            print("\n Opção inválida. Tente novamente.")
            time.sleep(1)


if __name__ == "__main__":
    executar_sistema()